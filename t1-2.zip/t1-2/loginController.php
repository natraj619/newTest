<?php include('config.php');?>

<?php

if (isset($_POST['signUp'])) 
{
$userEmail=$_REQUEST['userEmail'];
$userPassword=$_REQUEST['userPassword'];
$userTypeId = 1;


$attributes = array(    
          "userEmail" => $userEmail,
          "userPassword" => $userPassword,
          "userTypeId" => 1
                     );
      //  $postfield = json_encode($attributes);
        
        $header = array(
              'Accept: application/json',
              'Content-Type: application/json',
              "Authorization: Basic". base64_encode("tapceipt16:tapceipt16")
                );
      
        $ch = curl_init();
       // http://dev.tapceipt.com:9010/TapceiptRS/userSecurity/validateWebLogin?access_token=28494313-f505-4b2e-ba7d-757eb56c0f26

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL,'http://dev.tapceipt.com:9010/TapceiptRS/userSecurity/validateWebLogin?userEmail=$userEmail&userPassword=$userPassword&userTypeId=1');
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $postfield);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $result = curl_exec($ch);
        // curl_close($ch);
        print_r($result); echo"<br/>";
        
?>

<script type="text/javascript">
alert('User Login Successfully..');
</script>

<?php
}
?>

<?php // header("Location: home.php");  ?>
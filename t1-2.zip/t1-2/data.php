<?php

include('config.php'); 
session_start();
if($_POST['first_data']=='bsdata')
{

	$bname  =  $_POST['bname'];
	$cat    =  $_POST['cat'];
	$cpname =  $_POST['cpname'];
	$email  =  $_POST['email'];
	$phno   =  $_POST['phno'];
	$sql = "INSERT INTO Buisness(Name,Category,Contact_name,Email,Phno)values('".$bname."','".$cat."','".$cpname."','".$email."','".$phno."')";
	$query = mysqli_query($conn,$sql);

	$_SESSION['sucss'] = "Business Information successfully Submited";

	// echo $_SESSION['sucss'];
	// exit;
	header("Location:home.php");
}
if($_POST['first_data']=='storedata')
{
	
	$sname  =  $_POST['sname'];
	$saddress  =  $_POST['saddress'];
	$pno =  $_POST['num'];
	$city  =  $_POST['city'];
	$phno   =  $_POST['phno'];
	$email = $_POST['email1'];
	$state =  $_POST['state'];
	$terminals = $_POST['terminals'];
	$pincode = $_POST['pincode'];

	
	$sql =  "INSERT INTO Store(sname,saddress,phno,city,email,state,terminals,pincode)values('".$sname."','".$saddress."','".$pno."','".$city."','".$email."','".$state."','".$terminals."','".$pincode."')";
	$query = mysqli_query($conn,$sql);

	$_SESSION['sucss'] = "Store Information successfully Submited";

	
	header("Location:home.php");
}
if($_POST['ter'] == 'terdatas' )
{

	$d1 = $_POST['d1'];
	$d2 = $_POST['d2'];
	$d3 = $_POST['d3'];
	$d4 = $_POST['d4'];
	$d5 = $_POST['d5'];
	$d6 = $_POST['d6'];
	$d7 = $_POST['d7'];
	$d8 = $_POST['d8'];
	$d9 = $_POST['d9'];
	$d10 = $_POST['d10'];
	$d11 = $_POST['d11'];
	$d12 = $_POST['d12'];
	$d13 = $_POST['d13'];
	$d14 = $_POST['d14'];
	$d15 = $_POST['d15'];

	 $sql = "INSERT INTO Terminals(d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15)values('".$d1."','".$d2."','".$d3."','".$d4."','".$d5."','".$d6."','".$d7."','".$d8."','".$d9."','".$d10."','".$d11."','".$d12."','".$d13."','".$d14."','".$d15."')";

	 $query = mysqli_query($conn,$sql);

	 	header("Location:home.php");
}

?>
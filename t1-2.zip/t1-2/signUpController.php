<?php include('config.php');?>

<?php

if (isset($_POST['signUp'])) 
{
$userFirstName=$_REQUEST['userFirstName'];
// echo $userFirstName;
$userLastName=$_REQUEST['userLastName'];
//echo $username;
$userEmail=$_REQUEST['userEmail'];
//echo $password;
$userPassword=$_REQUEST['userPassword'];
//echo $cpass;
$userCountryCode=$_REQUEST['userCountryCode'];
$userContactNumber=$_REQUEST['userContactNumber'];
$userTypeId = 1;
$lastUpdatedDate=date('Y-m-d');


$attributes = array(    
					"userEmail" => $userEmail,
					"userPassword" => $userPassword,
					"userFirstName" => $userFirstName,
					"userLastName" => $userLastName,
					"userContactNumber" => $userContactNumber,
					"userCountryCode" => $userCountryCode,
				"userTypeId" => 1
                     );
        $postfield = json_encode($attributes);
        
        $header = array(
              'Accept: application/json',
              'Content-Type: application/json',
              "Authorization: Basic". base64_encode("tapceipt16:tapceipt16")
                );
      
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL,'http://dev.tapceipt.com:9010/TapceiptRS/userSecurity/webUser');
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postfield);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $result = curl_exec($ch);
        // curl_close($ch);
        print_r($result); echo"<br/>";
        print_r($postfield);




$sql="insert into signup(userFirstName,userLastName,userEmail,userPassword,userCountryCode, 
	userContactNumber,userTypeId,lastUpdatedDate) 
    values('".$userFirstName."', 
	'".$userLastName."','".$userEmail."','".$userPassword."',
	'".$userCountryCode."','".$userContactNumber."','".$userTypeId."','".$lastUpdatedDate."')";

// ,'".$userActiveStatus."','".$maskUserEmail."',
//	'".$stagingId."','".$receiptSourceTypeId."'
//,userActiveStatus,maskUserEmail,stagingId,receiptSourceTypeId
//  echo $sql;

?>

<script type="text/javascript">
alert('User Successfully Created..');
</script>

<?php
 
if($conn->query($sql))
{
//	echo "Data Inserted";
}
else
{
//	echo "<br><b>"."Data Not Inserted"."</b>";
}

}
?>




<?php

// header("Location: home.php"); 
		
?>
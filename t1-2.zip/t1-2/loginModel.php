<?php include('config.php');?>

<?php

      $userEmail=$_REQUEST['userEmail'];
      $userPassword=$_REQUEST['userPassword'];

      $sql="select count(*) as id from employe_profiles where id='".$username."' and password='".$password."' and department='".$depart_name."'  ";

      echo $sql;

      $result = mysqli_query($conn, $sql);

      while($row = mysqli_fetch_assoc($result))
      {
      //echo $row["id"];

      if($row["id"]==0)
      {
        //echo "Invalid";
        header("Location:home.php");  
        ?>

        <?php
      }
      }
?>



<?php

header("Location: pages/samples/register.php"); 
exit;		
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Tapceipt</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="favicon.png">
    <style type="text/css">

      .Error{
        color:red;
      }
    body {
        color: #404E67;
        background: #F5F7FA;
    font-family: 'Open Sans', sans-serif;
  }
  .table-wrapper {
    width: 700px;
    margin: 30px auto;
        background: #fff;
        padding: 20px;  
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
    .table-title {
        padding-bottom: 10px;
        margin: 0 0 10px;
    }
    .table-title h2 {
        margin: 6px 0 0;
        font-size: 22px;
    }
    .table-title .add-new {
        float: right;
    height: 30px;
    font-weight: bold;
    font-size: 12px;
    text-shadow: none;
    min-width: 100px;
    border-radius: 50px;
    line-height: 13px;
    }
  .table-title .add-new i {
    margin-right: 4px;
  }
    table.table {
        table-layout: fixed;
    }
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
    }
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }
    table.table th:last-child {
        width: 100px;
    }
    table.table td a {
    cursor: pointer;
        display: inline-block;
        margin: 0 5px;
    min-width: 24px;
    }    
  table.table td a.add {
        color: #27C46B;
    }
    table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #E34724;
    }
    table.table td i {
        font-size: 19px;
    }
  table.table td a.add i {
        font-size: 24px;
      margin-right: -1px;
        position: relative;
        top: 3px;
    }    
    table.table .form-control {
        height: 32px;
        line-height: 32px;
        box-shadow: none;
        border-radius: 2px;
    }
  table.table .form-control.error {
    border-color: #f50000;
  }
  table.table td .add {
    display: none;
  }
</style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_navbar.php -->
      <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="home.php"><img src="assets/images/logo.png" alt="logo" /></a>
          <a class="navbar-brand brand-logo-mini" href="home.php"><img src="assets/images/logo-mini.png" alt="logo" /></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
             
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-cached mr-2 text-success"></i> Activity Log </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="login.php">
                  <i class="mdi mdi-logout mr-2 text-primary"></i> Signout </a>
              </div>
            </li>
            <li class="nav-item d-none d-lg-block full-screen-link">
              <a class="nav-link">
                <i class="mdi mdi-fullscreen" id="fullscreen-button"></i>
              </a>
            </li>
            <li class="nav-item nav-logout d-none d-lg-block">
              <a class="nav-link" href="login.php">
                <i class="mdi mdi-power"></i>
              </a>
            </li>
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
      </nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.php -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav" >
            
            <li class="nav-item">
              <a class="nav-link" href="home.php">
                <span class="menu-title" style="color: #1b9869;">Add New Client</span>
                <i class="mdi mdi-home menu-icon" style="color: #1b9869;"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="clients.php">
                <span class="menu-title" style="color: #1b9869;">Clients</span>
                <i class="mdi mdi-chart-bar menu-icon" style="color: #1b9869;"></i>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="home.php">
                <span class="menu-title" style="color: #1b9869;">Reports</span>
                <i class="mdi mdi-table-large menu-icon" style="color: #1b9869;"></i>
              </a>
            </li>
          </ul>
        </nav>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            
            <div class="row">
              <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Add New Client</h4>
                    <div class="container">
  <ul class="nav nav-pills">
    
    <li><a data-toggle="pill" class="btn btn-primary btn-fw" href="#home">Business</a></li> 
    <li><a data-toggle="pill" class="btn btn-secondary btn-fw" href="#menu1">Store</a></li>
    <li><a class="btn btn-danger btn-fw" data-toggle="pill" href="#menu2">Product</a></li>
    <li><a data-toggle="pill" class="btn btn-warning btn-fw" href="#menu3">Payment</a></li>
     <li><a data-toggle="pill" class="btn btn-info btn-fw" href="#menu4">Review / Submit</a></li>
  </ul>
  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <div class="col-md-11 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <?php 
                    session_start();
                    if($_SESSION['sucss'])
                    {
                    ?>
                      <span style="color:green;"><?php echo $_SESSION['sucss']; ?></span>

                    <?}?>
                        
                    

                   <form class="forms-sample" id="bsform" method="post" action="data.php">
                      <div class="form-group row">
                        <label for="exampleInputUsername2" class="col-sm-3 col-form-label">Business Name</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="bname" placeholder="Business Name" name="bname">
                          <span class="Error" id="bname_error"></span>
                        </div>
                      </div>

                        <input type="hidden" value="bsdata" name="first_data">
                     
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Select Business Category</label>
                            <div class="col-sm-9">
                              <select class="form-control" id="cat" name="cat">
                                <option value="0">-Select-</option>
                                <option value="1">Italy</option>
                                <option value="2">Russia</option>
                                <option value="3">Britain</option>
                              </select>
                              <span class="Error" id="cat_error"></span>
                            </div>
                          </div>
                        
                      <div class="form-group row">
                        <label for="exampleInputMobile" class="col-sm-3 col-form-label">Primary Contact Person Name</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="cpname" placeholder="Contact Person Name" name="cpname">
                          <span class="Error" id="cpname_error"></span>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="exampleInputPassword2" class="col-sm-3 col-form-label">Email</label>
                        <div class="col-sm-9">
                          <input type="email" class="form-control" id="email" placeholder="Email" name="email">
                          <span class="Error" id="email_error"></span>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="exampleInputConfirmPassword2" class="col-sm-3 col-form-label">Phone Number</label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" id="phno" placeholder="Phone Number" name="phno">
                          <span class="Error" id="phno_error"></span>

                        </div>
                      </div>
                     <div align="right">
                      <button class="btn btn-light pull-right">Cancel</button>
                      <button type="button" class="btn btn-gradient-success btn-rounded btn-fw" onclick="javascript:bsdata();">Next</button></div>
                    </form>
                  </div>
                </div>
              </div>
    </div>
    <div id="menu1" class="tab-pane fade">
      <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Store Name</th>
                          <th>Address</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                        include('config.php'); 

                        $query=mysqli_query($conn,'select * from Store');
                        while($row = mysqli_fetch_array($query))
                        {?>
                          <tr>
                          <td><?php echo $row['sname']; ?></td>
                          <td><?php echo $row['saddress']; ?></td>
                        </tr>
                        <?}
                        ?>
                        
                      </tbody>
                    </table>
                    
            </div>
        </div>
      </div>

<h1 align="center">Store Details</h1>
                    <form class="form-sample" method="post" id="store" action="data.php">
                     
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Store Name</label>
                            <div class="col-sm-9">
                              <input type="text" name="sname" id="sname" class="form-control" />
                              <input type="hidden" value="storedata" name="first_data">

                              <span class="Error" id="sname_error"></span>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Store Address</label>
                            <div class="col-sm-9">
                              <input type="text" name="saddress" id="saddress" class="form-control" />
                              <span class="Error" id="saddress_error"></span>
                            </div>
                          </div>
                        </div>
                      </div>
                                          
                      <div class="row">
                         <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Phone no</label>
                            <div class="col-sm-9">
                              <input type="text" name="num" id="num" class="form-control" />
                              <span class="Error" id="num_error"></span>

                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">City</label>
                            <div class="col-sm-9">
                              <input type="text" name="city" id="city" class="form-control" />
                              <span class="Error" id="city_error"></span>

                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-9">
                              <input type="text" name="email1" id="email1" class="form-control" />
                              <span class="Error" id="email1_error"></span>

                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">State</label>
                            <div class="col-sm-9">
                              <input type="text" name="state" id="state" class="form-control" />
                                <span class="Error" id="state_error"></span>

                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                            <label class="col-sm-3 col-form-label">No.of Terminals</label>
                            <div class="col-sm-9">
                              <input type="text" name="terminals" id="terminals" class="form-control" />
                              <span class="Error" id="terminals_error"></span>

                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group row">
                                 <label class="col-sm-3 col-form-label">Pincode</label>
                            <div class="col-sm-9">
                              <input type="text"  name="pincode" id="pincode" class="form-control" />
                              <span class="Error" id="pin_error"></span>

                            </div>
                          </div>
                        </div>
                      </div>
                      <div align="right">
                      <button type="button" onclick="javascript:storedata();"   class="btn btn-gradient-success btn-rounded btn-fw"><i class="mdi mdi-briefcase"></i> Add Store</button>
                    </div>
                    </form>




<form class="form-horizontal" method="post" action="data.php" id="terform">
  <div class="table-responsive">
    <table class="table table-bordered table-striped table-highlight">
      <thead>
       <h3 class="card-header text-center font-weight-bold py-4">Terminal Details</h3>
         
      </thead>
      <tbody>
        <tr>
          <td><input type="text" class="form-control" name="d1" id="d1" value="" />
          <span class="Error" id="d1_error"></span>
          </td>
          <td><input type="text" class="form-control" name="d2" id="d2" value="" />
                      <input type="hidden" value="terdatas" id="ter" name="ter">

                    <span class="Error" id="d2_error"></span>
</td>
          <td>     
           <select class="form-control" name="d3" id="d3">
            <option value="0">-Select-</option>
           <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
            <span class="Error" id="d3_error"></span>

         </td>
          <td><input type="text" name="d4" id="d4" class="form-control" value="" />
          <span class="Error" id="d4_error"></span>

          </td>
          <td>     
           <select class="form-control" name="d5" id="d5">
            <option value="0">-Select-</option>
            <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
            <span class="Error" id="d5_error"></span>

         </td>
        </tr>
        <tr>
                 
        </tr>
        <tr>
          <td><input type="text" class="form-control" name="d6" id="d6" value="" />
              <span class="Error" id="d6_error"></span>

          </td>
          <td><input type="text" class="form-control" name="d7" id="d7" value="" />
             <span class="Error" id="d7_error"></span>

          </td>
          <td>     
           <select class="form-control" name="d8" id="d8">
            <option value="0">-Select-</option>
            <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
          <span class="Error" id="d8_error"></span>
  
         </td>
        <td>
      <input type="text" name="d9" id="d9" class="form-control" value="" />
           <span class="Error" id="d9_error"></span>
         </td>
          <td>     
           <select class="form-control" name="d10" id="d10">
            <option value="0">-Select-</option>
           <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
            <span class="Error" id="d10_error"></span>

         </td>
       
        </tr>
        <tr></tr>
        <tr>
          <td><input type="text" name="d11" id="d11" class="form-control" value="" />
          <span class="Error" id="d11_error"></span>

          </td>
          <td><input type="text" name="d12" id="d12" class="form-control" value="" />
            <span class="Error" id="d12_error"></span>

          </td>
          <td>     
           <select class="form-control" name="d13" id="d13">
            <option value="0">-Select-</option>
          <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
            <span class="Error" id="d13_error"></span>
 
         </td>
          <td><input type="text" name="d14" id="d14" class="form-control" value="" />
            <span class="Error" id="d14_error"></span>

          </td>
          <td>     
           <select class="form-control" name="d15" id="d15">
            <option value="0">-Select-</option>
            <option value="1">oneee</option>
            <option value="2">two00</option>
            <option value="3">three</option>
            </select>
            <span class="Error" id="d15_error"></span>
         </td>
        </tr>
        <tr></tr>
      </tbody>    
    </table>
  </div>
    <div align="right">
      <button type="button" onclick="javascript:terdata();"  class="btn btn-gradient-success btn-rounded btn-fw">Save Store</button></div>
  </form>
       <div align="right">
      <button class="btn btn-light pull-right">Cancel</button>
       <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Previous</button>
        <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Next</button>
    </div> 
    </div>


    <div id="menu2" class="tab-pane fade">
       <div class="col-md-11 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                     <form class="forms-sample" method="post">
                                        
                          <div class="form-group row">
                              
                            <div class="col-sm-9">
                              <select class="form-control">
                                <option>Select Digital Receipt Product</option>
                                <option>Italy</option>
                                <option>Russia</option>
                                <option>Britain</option>
                              </select>
                            </div>
                               <label class="col-sm-3 col-form-label">Rs.xxx/month</label>
                          </div>


                          <div class="form-group row">
                            
                            <div class="col-sm-9">
                              <select class="form-control">
                                <option>Select Yearly Credits Package</option>
                                <option>Italy</option>
                                <option>Russia</option>
                                <option>Britain</option>
                              </select>
                            </div>
                               <label class="col-sm-3 col-form-label">Rs.xxx/year</label>
                          </div>
                          <div class="form-group row">                      
                            <div class="col-sm-9">
                              <select class="form-control">
                                <option>Select Marketing Product</option>
                                <option>Italy</option>
                                <option>Russia</option>
                                <option>Britain</option>
                              </select>
                            </div>
                               <label class="col-sm-3 col-form-label">Rs.xxx/month</label>
                          </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                              
                            </div>
                               <label class="col-sm-3 col-form-label">Total Rs.xxx/month</label>
                          </div>
                        
                     <div align="right">
                      <button class="btn btn-light pull-right">Cancel</button>
                      <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Previous</button>
                    <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Next</button></div>
                    </form>
                  </div>
                </div>
              </div>
    </div>
    <div id="menu3" class="tab-pane fade">
      <div align="right">
      <button class="btn btn-light pull-right">Cancel</button>
       <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Previous</button>
       <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Skip</button>
        <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Next</button>
    </div>
    </div>

    <div id="menu4" class="tab-pane fade">
       <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Business</h2></div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Business Name</th>
                        <th>Contact Person</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tradding</td>
                        <td>Tessa</td>
                        <td>tessa@mail.com</td>
                        <td>8220624101</td>
                        <td>
              <a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a>
              <a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        </td>              
                    </tr>        
                </tbody>
               </table>
        </div>
    </div>

<div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Store</h2></div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Business Name</th>
                        <th>Contact Person</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tradding</td>
                        <td>Tessa</td>
                        <td>tessa@mail.com</td>
                        <td>8220624101</td>
                        <td>
              <a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a>
              <a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        </td>              
                    </tr>        
                </tbody>
               </table>
        </div>
    </div>

<div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Product</h2></div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Business Name</th>
                        <th>Contact Person</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tradding</td>
                        <td>Tessa</td>
                        <td>tessa@mail.com</td>
                        <td>8220624101</td>
                        <td>
              <a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a>
              <a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        </td>              
                    </tr>        
                </tbody>
               </table>
        </div>
    </div>
<div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><h2>Payment</h2></div>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Business Name</th>
                        <th>Contact Person</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tradding</td>
                        <td>Tessa</td>
                        <td>tessa@mail.com</td>
                        <td>8220624101</td>
                        <td>
              <a class="add" title="Add" data-toggle="tooltip"><i class="material-icons">&#xE03B;</i></a>
              <a class="edit" title="Edit" data-toggle="tooltip"><i class="material-icons">&#xE254;</i></a>
                        </td>              
                    </tr>        
                </tbody>
               </table>
        </div>
    </div>

    <div class="row" align="right">
      <button class="btn btn-light pull-right">Cancel</button>
       <button type="submit" class="btn btn-gradient-success btn-rounded btn-fw">Submit</button>
    </div>

      
  </div>
</div>

                    
                  </div>
                </div>
              </div>
             
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.php -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2019 <a href="https://www.tapceipt.com/" target="_blank">Tapceipt</a>. All rights reserved.</span>
             
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/todolist.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript">
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
  var actions = $("table td:last-child").html();
  // Append table with add row form on add new button click
    $(".add-new").click(function(){
    $(this).attr("disabled", "disabled");
    var index = $("table tbody tr:last-child").index();
        var row = '<tr>' +
            '<td><input type="text" class="form-control" name="name" id="name"></td>' +
            '<td><input type="text" class="form-control" name="department" id="department"></td>' +
            '<td><input type="text" class="form-control" name="phone" id="phone"></td>' +
      '<td>' + actions + '</td>' +
        '</tr>';
      $("table").append(row);   
    $("table tbody tr").eq(index + 1).find(".add, .edit").toggle();
        $('[data-toggle="tooltip"]').tooltip();
    });
  // Add row on add button click
  $(document).on("click", ".add", function(){
    var empty = false;
    var input = $(this).parents("tr").find('input[type="text"]');
        input.each(function(){
      if(!$(this).val()){
        $(this).addClass("error");
        empty = true;
      } else{
                $(this).removeClass("error");
            }
    });
    $(this).parents("tr").find(".error").first().focus();
    if(!empty){
      input.each(function(){
        $(this).parent("td").html($(this).val());
      });     
      $(this).parents("tr").find(".add, .edit").toggle();
      $(".add-new").removeAttr("disabled");
    }   
    });
  // Edit row on edit button click
  $(document).on("click", ".edit", function(){    
        $(this).parents("tr").find("td:not(:last-child)").each(function(){
      $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
    });   
    $(this).parents("tr").find(".add, .edit").toggle();
    $(".add-new").attr("disabled", "disabled");
    });
  // Delete row on delete button click
  $(document).on("click", ".delete", function(){
        $(this).parents("tr").remove();
    $(".add-new").removeAttr("disabled");
    });
});


function bsdata()
{
  var bname = $("#bname").val();
  var cat   = $("#cat").val();
  var cpname= $("#cpname").val();
  var email = $("#email").val();
  var phno  = $("#phno").val();
  if(bname == "")
  {
    $("#bname_error").html("please enter the buisness name");
  }
  if(cat == 0)
  {
    $("#cat_error").html("please select the category");
  }
  if(cpname == "")
  {
    $("#cpname_error").html("please enter the person name");
  }
  if(email == "")
  {
    $("#email_error").html("please enter the email");
  }
  if(phno == "")
  {
    $("#phno_error").html("please enter the phone number");
  }
  if(bname!="" && cat!=0 && cpname!="" && email!="" && phno!="")
  {
    document.getElementById("bsform").submit();
  }
}


function storedata()
{
  var sname = $("#sname").val();
  var saddress = $("#saddress").val();
  var num = $("#num").val();
  var city = $("#city").val();
  var email = $("#email1").val();
  var state = $("#state").val();
  var terminals = $("#terminals").val();
  var pincode = $("#pincode").val();


   if(sname == "")
  {
    $("#sname_error").html("please enter the  store name");
  }
  if(saddress == "")
  {
    $("#saddress_error").html("please enter the store address");
  }
   if(num == "")
  {
    $("#num_error").html("please enter the  phone name");
  }
  
  if(city == "")
  {
    $("#city_error").html("please enter the city");
  }
  if(email == "")
  {
    $("#email1_error").html("please enter the email");
  }
  if(state == "")
  {
    $("#state_error").html("please enter the state");
  }
  if(terminals == "")
  {
    $("#terminals_error").html("please enter the terminals");
  }
  if(pincode == "")
  {
    $("#pin_error").html("please enter the  pin code");
  }

  if(sname!="" && saddress!="" && num!="" && city!="" && email!="" && state!="" && terminals!="" && pincode!="")
  {
    document.getElementById("store").submit();

  }
}


function terdata()
{
  var d1 = $("#d1").val();
  var d2 = $("#d2").val();
  var d3 = $("#d3").val();
  var d4 = $("#d4").val();
  var d5 = $("#d5").val();
  var d6 = $("#d6").val();
  var d7 = $("#d7").val();
  var d8 = $("#d8").val();
  var d9 = $("#d9").val();
  var d10 = $("#d10").val();
  var d11 = $("#d11").val();
  var d12 = $("#d12").val();
  var d13 = $("#d13").val();
  var d14 = $("#d14").val();
  var d15 = $("#d15").val();

  if(d1 == "")
  {
    $("#d1_error").html("please enter the value");
  }
  if(d2 == "")
  {
    $("#d2_error").html("please enter the value");
  }
  if(d3 == "0")
  {
    $("#d3_error").html("please select the value");
  }
   if(d4 == "")
  {
    $("#d4_error").html("please enter the value");
  }
   if(d5 == "0")
  {
    $("#d5_error").html("please select the value");
  }
   if(d6 == "")
  {
    $("#d6_error").html("please enter the value");
  }
   if(d7 == "")
  {
    $("#d7_error").html("please enter the value");
  }
   if(d8 == "0")
  {
    $("#d8_error").html("please select the value");
  }
    if(d9 == "")
  {
    $("#d9_error").html("please enter the value");
  }
    if(d10 == "0")
  {
    $("#d10_error").html("please select the value");
  }
    if(d11 == "")
  {
    $("#d11_error").html("please enter the value");
  }
    if(d12 == "")
  {
    $("#d12_error").html("please enter the value");
  }
    if(d13 == "0")
  {
    $("#d13_error").html("please select the value");
  }
  if(d14 == "")
  {
    $("#d14_error").html("please enter the value");
  }
    if(d15 == "0")
  {
    $("#d15_error").html("please select the value");
  }



if(d1!="" && d2!="" && d3!=0 && d4!="" && d5!=0 && d6!="" && d7!="" && d8!=0 && d9!="" && d10!=0 && d11!="" && d12!="" && d13!=0 && d14!="" && d15!=0)
{
  document.getElementById("terform").submit();
}

}
 </script>
    <!-- End custom js for this page -->
  </body>
</html>
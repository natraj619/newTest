<?php

$server="localhost";
$user="axionpcs_user";
$password="axion2user";
$db="axionpcs_homepage";

$conn = new mysqli($server,$user,$password,$db);

if ($conn->connect_error)
 {
 	die("connection failed:".$conn->connect_error);
 } 
else
{
// 	echo "connected";
}
?>
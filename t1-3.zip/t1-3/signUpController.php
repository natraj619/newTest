<?php include('config.php');?>

<?php

if (isset($_POST['signUp'])) 
{
$userFirstName=$_REQUEST['userFirstName'];
$userLastName=$_REQUEST['userLastName'];
$userEmail=$_REQUEST['userEmail'];
$userPassword=$_REQUEST['userPassword'];
$userCountryCode=$_REQUEST['userCountryCode'];
$userContactNumber=$_REQUEST['userContactNumber'];
$userTypeId = 1;
$lastUpdatedDate=date('Y-m-d');


$attributes = array(    
					"userEmail" => $userEmail,
					"userPassword" => $userPassword,
					"userFirstName" => $userFirstName,
					"userLastName" => $userLastName,
					"userContactNumber" => $userContactNumber,
					"userCountryCode" => $userCountryCode,
				    "userTypeId" => 1
                     );
        $postfield = json_encode($attributes);
        
        $header = array(
              'Accept: application/json',
              'Content-Type: application/json',
              "Authorization: Basic". base64_encode("tapceipt16:tapceipt16")
                );
      
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_URL,'http://dev.tapceipt.com:9010/TapceiptRS/userSecurity/webUser');
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postfield);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        $result = curl_exec($ch);
        curl_close($ch);
        
}

$sql="insert into signup(userFirstName,userLastName,userEmail,userPassword,userCountryCode, 
	userContactNumber,userTypeId,lastUpdatedDate) 
    values('".$userFirstName."', 
	'".$userLastName."','".$userEmail."','".$userPassword."',
	'".$userCountryCode."','".$userContactNumber."','".$userTypeId."','".$lastUpdatedDate."')";

echo "<script> window.location.href = 'login.php';</script>";
?>

<?php include('config.php');?>

<?php

         
         
          $userEmail = $_POST['userEmail'];
          $userPassword = $_POST['userPassword'];
          
          
          $attributes = array(
                  "userEmail" => $userEmail,
                  "userPassword" => $userPassword,
                  "userTypeId" => "1"
                    );
                    
          $postfield = json_encode($attributes);

          $ch1 = curl_init();
        
          curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch1, CURLOPT_URL,'http://dev.tapceipt.com:9010/TapceiptRS/userSecurity/validateWebLogin?access_token='.$token);
          curl_setopt($ch1, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
          curl_setopt($ch1, CURLOPT_POST, true);
          curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch1, CURLOPT_POSTFIELDS, $postfield);
          curl_setopt($ch1, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Accept: application/json',
                    "Authorization: Basic bXktdHJ1c3RlZC1jbGllbnQ6c2VjcmV0"
                   ));
                $response1 = curl_exec($ch1);
                curl_close($ch1);
                // $r = json_encode($response1);
                // print_r($response1); echo"<br/>";
                // exit();
                // $json = json_decode($result);
          
           
echo "<script> window.location.href = 'home.php';</script>";
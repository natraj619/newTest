-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 01, 2019 at 10:50 AM
-- Server version: 5.7.27-0ubuntu0.16.04.1
-- PHP Version: 7.1.30-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tapceipt`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `userFirstName` varchar(100) DEFAULT NULL,
  `userLastName` varchar(100) DEFAULT NULL,
  `userEmail` varchar(100) DEFAULT NULL,
  `userPassword` varchar(300) DEFAULT NULL,
  `userCountryCode` varchar(101) DEFAULT NULL,
  `userContactNumber` varchar(15) DEFAULT NULL,
  `userTypeId` int(11) DEFAULT NULL,
  `userActiveStatus` varchar(20) DEFAULT NULL,
  `receiptFileId` int(11) DEFAULT NULL,
  `maskUserEmail` varchar(100) DEFAULT NULL,
  `stagingId` int(11) DEFAULT NULL,
  `receiptSourceTypeId` int(11) DEFAULT NULL,
  `lastUpdatedDate` datetime DEFAULT NULL,
  `createdOn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `userId`, `userFirstName`, `userLastName`, `userEmail`, `userPassword`, `userCountryCode`, `userContactNumber`, `userTypeId`, `userActiveStatus`, `receiptFileId`, `maskUserEmail`, `stagingId`, `receiptSourceTypeId`, `lastUpdatedDate`, `createdOn`) VALUES
(1, NULL, 'natraj', 'k', 'raj.nat619@gmail.com', '123456', '91', '8220624101', NULL, NULL, NULL, NULL, NULL, NULL, '2019-11-28 00:00:00', '2019-11-28 02:03:42'),
(2, NULL, '', '', '', 'cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e', '', '', NULL, NULL, NULL, NULL, NULL, NULL, '2019-11-28 00:00:00', '2019-11-28 02:35:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `userEmail` (`userEmail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
